module.exports = {
  list: ["test", "feat", "fix", "chore", "docs", "refactor"],
  maxMessageLength: 64,
  minMessageLength: 3,
  questions: ["type", "subject", "breaking", "issues"],
};